##
## IOSAMPLER SERVER
##

from flask import Flask, session, redirect, url_for, escape, request, flash
import pyglet

app = Flask (__name__)

@app.route('/')
def index():
    if 'username' in session:
        return 'Logged in as %s' % escape(session['username'])
    return ' You are not logged in'

keyC = pyglet.media.load('notes/C.wav', streaming=False)
keyD = pyglet.media.load('notes/D.wav', streaming=False)
keyE = pyglet.media.load('notes/E.wav', streaming=False)
keyF = pyglet.media.load('notes/F.wav', streaming=False)
keyG = pyglet.media.load('notes/G.wav', streaming=False)

@app.route('/play/<note>')
def play(note):
    if note == 'C':
        keyC.play()
        return ('C')
    elif note == 'D':
        keyD.play()
        return ('D')
    elif note == 'E':
        keyE.play()
        return ('E')
    elif note == 'F':
        keyF.play()
        return ('F')
    elif note == 'G':
        keyG.play()
        return ('G')

if __name__ == "__main__":
        app.run()

