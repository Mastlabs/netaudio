##
## IOSAMPLER CLIENT
##

import requests
import pyglet
from pyglet.window import key

window = pyglet.window.Window()

@window.event
def on_key_press(symbol, modifiers):
    if symbol == key.C:
        r = requests.get('http://127.0.0.1:5000/play/' + 'C')
        print 'C key was pressed'
    elif symbol == key.D:
        r = requests.get('http://127.0.0.1:5000/play/' + 'D')
        print 'D key was pressed'
    elif symbol == key.E:
        r = requests.get('http://127.0.0.1:5000/play/' + 'E')
        print 'E key was pressed'
    else:
        print 'Bad key was pressed'

@window.event
def on_draw():
    window.clear()

if __name__ == "__main__":
    pyglet.app.run()
